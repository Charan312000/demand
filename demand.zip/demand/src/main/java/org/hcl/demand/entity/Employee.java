package org.hcl.demand.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Employee {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column(name = "sap_ID")
    private Long sapid;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "band")
    private String band;

    @Column(name = "sub_band")
    private String subBand;

    @Column(name = "email")
    private String email;

    @Column(name = "primary_skill")
    private String primarySkill;

    @Column(name = "experience")
    private Double experience;

    @Column(name = "relevant_exp")
    private Double relevantExp;

    @Column(name = "location")
    private String location;

    @Column(name = "bench_date")
    private LocalDate benchDate;

    @Column(name = "bench_ageing")
    private Integer benchAgeing;

    @Column(name = "country")
    private String country;

    @Column(name = "role")
    private String role;

    private String assignmentStatus;

    private String assignmentName;

    private String assignmentScore;

    private String assignmentTakenDate;

    private String recommendation;





}
