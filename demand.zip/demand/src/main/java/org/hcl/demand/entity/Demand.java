package org.hcl.demand.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "demand")
public class Demand {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @Column(name = "sr_number")
        private String srNumber;

        @Column(name = "sr_raised_date")
        private Date srRaisedDate;

        @Column(name = "billing_start_date")
        private Date billingStartDate;

        @Column(name = "sr_start_date")
        private Date srStartDate;

        @Column(name = "sr_status")
        private String srStatus;

        @Column(name = "primary_skill")
        private String primarySkill;

        @Column(name = "client_name")
        private String clientName;

        @Column(name = "l2_lob")
        private String l2Lob;

        @Column(name = "l4_lob")
        private String l4Lob;

        @Column(name = "band")
        private String band;

        @Column(name = "sub_band")
        private String subBand;

        @Column(name = "location")
        private String location;

        @Column(name = "no_of_position")
        private Integer noOfPosition;

        @Column(name = "initiator")
        private String initiator;

        @Column(name = "sap_id")
        private Long sapId;

        @Column(name = "initiator_email_id")
        private String initiatorEmailId;

}